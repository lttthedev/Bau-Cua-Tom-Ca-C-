﻿# Game bầu cua - Hướng dẫn
==========================<br/>
Mình có thêm thư mục Nhac cách sử dụng:<br/>
Sau khi Build -> Build Solution bạn sao chép (copy) thư mục Nhac<br/>
Bạn dán (paste) vào trong thư mục Debug của chương trình theo đường dẫn sau: GameBauCua\Main\bin\Debug
==========================<br/>
Để phát triển phần mềm các bạn cần tải và cài đặt những phần mềm sau:<br/>
Visual Studio 2010 hoặc 2015 Community: https://www.visualstudio.com/en-us/news/releasenotes/vs2015-update3-vs<br/>
Git: https://git-scm.com/downloads (chọn Windows - tải bản 32 bit hoặc 64 bit tùy vào hệ điều hành của máy)<br/>
TeamViewer (để Bảo có thể Support khi các bạn gặp trục trặc): https://download.teamviewer.com/download/TeamViewerQS.exe<br/>
==========================<br/>
Một số lệnh Git cần biết:<br/>
Xem tại đây: https://viblo.asia/p/tap-hop-nhung-cau-lenh-git-huu-dung-dWrvwWr2vw38<br/>
===========================<br/>
