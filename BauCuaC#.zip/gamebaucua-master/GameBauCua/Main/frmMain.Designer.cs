﻿namespace Main
{
    partial class frmMain
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            this.groupBox1 = new System.Windows.Forms.GroupBox();
            this.label2 = new System.Windows.Forms.Label();
            this.label1 = new System.Windows.Forms.Label();
            this.txtDatGa = new System.Windows.Forms.TextBox();
            this.txtDatBau = new System.Windows.Forms.TextBox();
            this.txtDatTom = new System.Windows.Forms.TextBox();
            this.txtDatCua = new System.Windows.Forms.TextBox();
            this.txtDatCa = new System.Windows.Forms.TextBox();
            this.txtDatNai = new System.Windows.Forms.TextBox();
            this.pictureBox4 = new System.Windows.Forms.PictureBox();
            this.pictureBox7 = new System.Windows.Forms.PictureBox();
            this.pictureBox5 = new System.Windows.Forms.PictureBox();
            this.pictureBox6 = new System.Windows.Forms.PictureBox();
            this.pictureBox3 = new System.Windows.Forms.PictureBox();
            this.picKetQua3 = new System.Windows.Forms.PictureBox();
            this.picKetQua2 = new System.Windows.Forms.PictureBox();
            this.picKetQua1 = new System.Windows.Forms.PictureBox();
            this.pictureBox2 = new System.Windows.Forms.PictureBox();
            this.lblTenNguoiChoi = new System.Windows.Forms.Label();
            this.lblDiem = new System.Windows.Forms.Label();
            this.picHinhDaiDien = new System.Windows.Forms.PictureBox();
            this.picXoc = new System.Windows.Forms.PictureBox();
            this.pictureBox1 = new System.Windows.Forms.PictureBox();
            this.ttipHinhDaiDien = new System.Windows.Forms.ToolTip(this.components);
            this.ctxMenuChoiGame = new System.Windows.Forms.ContextMenuStrip(this.components);
            this.menuChonNhac = new System.Windows.Forms.ToolStripMenuItem();
            this.menuPhatNhac = new System.Windows.Forms.ToolStripMenuItem();
            this.menuTamDung = new System.Windows.Forms.ToolStripMenuItem();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.menuDangXuat = new System.Windows.Forms.ToolStripMenuItem();
            this.groupBox1.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKetQua3)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKetQua2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKetQua1)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHinhDaiDien)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.picXoc)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).BeginInit();
            this.ctxMenuChoiGame.SuspendLayout();
            this.SuspendLayout();
            // 
            // groupBox1
            // 
            this.groupBox1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Right)));
            this.groupBox1.BackColor = System.Drawing.Color.Maroon;
            this.groupBox1.Controls.Add(this.label2);
            this.groupBox1.Controls.Add(this.label1);
            this.groupBox1.Controls.Add(this.txtDatGa);
            this.groupBox1.Controls.Add(this.txtDatBau);
            this.groupBox1.Controls.Add(this.txtDatTom);
            this.groupBox1.Controls.Add(this.txtDatCua);
            this.groupBox1.Controls.Add(this.txtDatCa);
            this.groupBox1.Controls.Add(this.txtDatNai);
            this.groupBox1.Controls.Add(this.pictureBox4);
            this.groupBox1.Controls.Add(this.pictureBox7);
            this.groupBox1.Controls.Add(this.pictureBox5);
            this.groupBox1.Controls.Add(this.pictureBox6);
            this.groupBox1.Controls.Add(this.pictureBox3);
            this.groupBox1.Controls.Add(this.picKetQua3);
            this.groupBox1.Controls.Add(this.picKetQua2);
            this.groupBox1.Controls.Add(this.picKetQua1);
            this.groupBox1.Controls.Add(this.pictureBox2);
            this.groupBox1.Font = new System.Drawing.Font("Microsoft Sans Serif", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.groupBox1.ForeColor = System.Drawing.SystemColors.ButtonHighlight;
            this.groupBox1.Location = new System.Drawing.Point(613, 15);
            this.groupBox1.Margin = new System.Windows.Forms.Padding(4);
            this.groupBox1.Name = "groupBox1";
            this.groupBox1.Padding = new System.Windows.Forms.Padding(4);
            this.groupBox1.Size = new System.Drawing.Size(1085, 826);
            this.groupBox1.TabIndex = 1;
            this.groupBox1.TabStop = false;
            this.groupBox1.Text = "Đặt cược";
            // 
            // label2
            // 
            this.label2.Location = new System.Drawing.Point(120, 549);
            this.label2.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(957, 41);
            this.label2.TabIndex = 3;
            this.label2.Text = "____________________________________________________________________\r\n\r\n";
            // 
            // label1
            // 
            this.label1.AutoSize = true;
            this.label1.Location = new System.Drawing.Point(8, 560);
            this.label1.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(116, 29);
            this.label1.TabIndex = 2;
            this.label1.Text = "Kết quả :";
            // 
            // txtDatGa
            // 
            this.txtDatGa.Location = new System.Drawing.Point(788, 250);
            this.txtDatGa.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatGa.Name = "txtDatGa";
            this.txtDatGa.ShortcutsEnabled = false;
            this.txtDatGa.Size = new System.Drawing.Size(288, 34);
            this.txtDatGa.TabIndex = 2;
            this.txtDatGa.Text = "0";
            this.txtDatGa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatNai_KeyPress);
            // 
            // txtDatBau
            // 
            this.txtDatBau.Location = new System.Drawing.Point(400, 250);
            this.txtDatBau.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatBau.Name = "txtDatBau";
            this.txtDatBau.ShortcutsEnabled = false;
            this.txtDatBau.Size = new System.Drawing.Size(288, 34);
            this.txtDatBau.TabIndex = 1;
            this.txtDatBau.Text = "0";
            this.txtDatBau.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatNai_KeyPress);
            // 
            // txtDatTom
            // 
            this.txtDatTom.Location = new System.Drawing.Point(788, 510);
            this.txtDatTom.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatTom.Name = "txtDatTom";
            this.txtDatTom.ShortcutsEnabled = false;
            this.txtDatTom.Size = new System.Drawing.Size(288, 34);
            this.txtDatTom.TabIndex = 5;
            this.txtDatTom.Text = "0";
            this.txtDatTom.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatNai_KeyPress);
            // 
            // txtDatCua
            // 
            this.txtDatCua.Location = new System.Drawing.Point(400, 510);
            this.txtDatCua.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatCua.Name = "txtDatCua";
            this.txtDatCua.ShortcutsEnabled = false;
            this.txtDatCua.Size = new System.Drawing.Size(288, 34);
            this.txtDatCua.TabIndex = 4;
            this.txtDatCua.Text = "0";
            this.txtDatCua.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatNai_KeyPress);
            // 
            // txtDatCa
            // 
            this.txtDatCa.Location = new System.Drawing.Point(11, 510);
            this.txtDatCa.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatCa.Name = "txtDatCa";
            this.txtDatCa.ShortcutsEnabled = false;
            this.txtDatCa.Size = new System.Drawing.Size(279, 34);
            this.txtDatCa.TabIndex = 3;
            this.txtDatCa.Text = "0";
            this.txtDatCa.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatNai_KeyPress);
            // 
            // txtDatNai
            // 
            this.txtDatNai.Location = new System.Drawing.Point(9, 251);
            this.txtDatNai.Margin = new System.Windows.Forms.Padding(4);
            this.txtDatNai.Name = "txtDatNai";
            this.txtDatNai.ShortcutsEnabled = false;
            this.txtDatNai.Size = new System.Drawing.Size(279, 34);
            this.txtDatNai.TabIndex = 0;
            this.txtDatNai.Text = "0";
            this.txtDatNai.KeyPress += new System.Windows.Forms.KeyPressEventHandler(this.txtDatNai_KeyPress);
            // 
            // pictureBox4
            // 
            this.pictureBox4.Image = global::Main.Properties.Resources._2;
            this.pictureBox4.Location = new System.Drawing.Point(788, 21);
            this.pictureBox4.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox4.Name = "pictureBox4";
            this.pictureBox4.Size = new System.Drawing.Size(289, 222);
            this.pictureBox4.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox4.TabIndex = 0;
            this.pictureBox4.TabStop = false;
            // 
            // pictureBox7
            // 
            this.pictureBox7.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox7.Image = global::Main.Properties.Resources._5;
            this.pictureBox7.Location = new System.Drawing.Point(788, 293);
            this.pictureBox7.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox7.Name = "pictureBox7";
            this.pictureBox7.Size = new System.Drawing.Size(289, 208);
            this.pictureBox7.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox7.TabIndex = 0;
            this.pictureBox7.TabStop = false;
            // 
            // pictureBox5
            // 
            this.pictureBox5.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox5.Image = global::Main.Properties.Resources._3;
            this.pictureBox5.Location = new System.Drawing.Point(8, 293);
            this.pictureBox5.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox5.Name = "pictureBox5";
            this.pictureBox5.Size = new System.Drawing.Size(281, 208);
            this.pictureBox5.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox5.TabIndex = 0;
            this.pictureBox5.TabStop = false;
            // 
            // pictureBox6
            // 
            this.pictureBox6.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox6.Image = global::Main.Properties.Resources._4;
            this.pictureBox6.Location = new System.Drawing.Point(400, 294);
            this.pictureBox6.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox6.Name = "pictureBox6";
            this.pictureBox6.Size = new System.Drawing.Size(289, 208);
            this.pictureBox6.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox6.TabIndex = 0;
            this.pictureBox6.TabStop = false;
            // 
            // pictureBox3
            // 
            this.pictureBox3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox3.Image = global::Main.Properties.Resources._1;
            this.pictureBox3.Location = new System.Drawing.Point(400, 21);
            this.pictureBox3.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox3.Name = "pictureBox3";
            this.pictureBox3.Size = new System.Drawing.Size(289, 222);
            this.pictureBox3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox3.TabIndex = 0;
            this.pictureBox3.TabStop = false;
            // 
            // picKetQua3
            // 
            this.picKetQua3.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picKetQua3.Location = new System.Drawing.Point(796, 593);
            this.picKetQua3.Margin = new System.Windows.Forms.Padding(4);
            this.picKetQua3.Name = "picKetQua3";
            this.picKetQua3.Size = new System.Drawing.Size(281, 225);
            this.picKetQua3.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picKetQua3.TabIndex = 0;
            this.picKetQua3.TabStop = false;
            // 
            // picKetQua2
            // 
            this.picKetQua2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picKetQua2.Location = new System.Drawing.Point(408, 593);
            this.picKetQua2.Margin = new System.Windows.Forms.Padding(4);
            this.picKetQua2.Name = "picKetQua2";
            this.picKetQua2.Size = new System.Drawing.Size(281, 225);
            this.picKetQua2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picKetQua2.TabIndex = 0;
            this.picKetQua2.TabStop = false;
            // 
            // picKetQua1
            // 
            this.picKetQua1.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picKetQua1.Location = new System.Drawing.Point(13, 593);
            this.picKetQua1.Margin = new System.Windows.Forms.Padding(4);
            this.picKetQua1.Name = "picKetQua1";
            this.picKetQua1.Size = new System.Drawing.Size(281, 225);
            this.picKetQua1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picKetQua1.TabIndex = 0;
            this.picKetQua1.TabStop = false;
            // 
            // pictureBox2
            // 
            this.pictureBox2.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox2.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.pictureBox2.Image = global::Main.Properties.Resources._0;
            this.pictureBox2.Location = new System.Drawing.Point(8, 34);
            this.pictureBox2.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox2.Name = "pictureBox2";
            this.pictureBox2.Size = new System.Drawing.Size(281, 208);
            this.pictureBox2.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox2.TabIndex = 0;
            this.pictureBox2.TabStop = false;
            // 
            // lblTenNguoiChoi
            // 
            this.lblTenNguoiChoi.AutoSize = true;
            this.lblTenNguoiChoi.BackColor = System.Drawing.Color.Maroon;
            this.lblTenNguoiChoi.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblTenNguoiChoi.ForeColor = System.Drawing.Color.Yellow;
            this.lblTenNguoiChoi.Location = new System.Drawing.Point(135, 15);
            this.lblTenNguoiChoi.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblTenNguoiChoi.Name = "lblTenNguoiChoi";
            this.lblTenNguoiChoi.Size = new System.Drawing.Size(261, 39);
            this.lblTenNguoiChoi.TabIndex = 2;
            this.lblTenNguoiChoi.Text = "Tên Người chơi";
            // 
            // lblDiem
            // 
            this.lblDiem.AutoSize = true;
            this.lblDiem.BackColor = System.Drawing.Color.Maroon;
            this.lblDiem.Font = new System.Drawing.Font("Microsoft Sans Serif", 20.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lblDiem.ForeColor = System.Drawing.Color.Yellow;
            this.lblDiem.Location = new System.Drawing.Point(153, 190);
            this.lblDiem.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblDiem.Name = "lblDiem";
            this.lblDiem.Size = new System.Drawing.Size(141, 39);
            this.lblDiem.TabIndex = 2;
            this.lblDiem.Text = "Điểm: 0";
            // 
            // picHinhDaiDien
            // 
            this.picHinhDaiDien.BackColor = System.Drawing.Color.Transparent;
            this.picHinhDaiDien.BackgroundImageLayout = System.Windows.Forms.ImageLayout.Stretch;
            this.picHinhDaiDien.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picHinhDaiDien.Image = global::Main.Properties.Resources.nam;
            this.picHinhDaiDien.Location = new System.Drawing.Point(161, 55);
            this.picHinhDaiDien.Margin = new System.Windows.Forms.Padding(4);
            this.picHinhDaiDien.Name = "picHinhDaiDien";
            this.picHinhDaiDien.Size = new System.Drawing.Size(229, 130);
            this.picHinhDaiDien.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picHinhDaiDien.TabIndex = 6;
            this.picHinhDaiDien.TabStop = false;
            this.ttipHinhDaiDien.SetToolTip(this.picHinhDaiDien, "Nhấn vào hình đại diện để đăng xuất");
            this.picHinhDaiDien.Click += new System.EventHandler(this.picHinhDaiDien_Click);
            // 
            // picXoc
            // 
            this.picXoc.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.picXoc.BackColor = System.Drawing.Color.Transparent;
            this.picXoc.Cursor = System.Windows.Forms.Cursors.Hand;
            this.picXoc.Image = global::Main.Properties.Resources._6;
            this.picXoc.Location = new System.Drawing.Point(0, 296);
            this.picXoc.Margin = new System.Windows.Forms.Padding(4);
            this.picXoc.Name = "picXoc";
            this.picXoc.Size = new System.Drawing.Size(557, 617);
            this.picXoc.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.picXoc.TabIndex = 3;
            this.picXoc.TabStop = false;
            this.picXoc.Click += new System.EventHandler(this.picXoc_Click);
            // 
            // pictureBox1
            // 
            this.pictureBox1.BackColor = System.Drawing.Color.Maroon;
            this.pictureBox1.Dock = System.Windows.Forms.DockStyle.Fill;
            this.pictureBox1.Image = global::Main.Properties.Resources._39;
            this.pictureBox1.Location = new System.Drawing.Point(0, 0);
            this.pictureBox1.Margin = new System.Windows.Forms.Padding(4);
            this.pictureBox1.Name = "pictureBox1";
            this.pictureBox1.Size = new System.Drawing.Size(1816, 913);
            this.pictureBox1.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pictureBox1.TabIndex = 0;
            this.pictureBox1.TabStop = false;
            // 
            // ttipHinhDaiDien
            // 
            this.ttipHinhDaiDien.ToolTipIcon = System.Windows.Forms.ToolTipIcon.Info;
            this.ttipHinhDaiDien.ToolTipTitle = "Đăng xuất";
            // 
            // ctxMenuChoiGame
            // 
            this.ctxMenuChoiGame.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.ctxMenuChoiGame.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.menuChonNhac,
            this.menuPhatNhac,
            this.menuTamDung,
            this.toolStripSeparator1,
            this.menuDangXuat});
            this.ctxMenuChoiGame.Name = "ctxMenuChoiGame";
            this.ctxMenuChoiGame.Size = new System.Drawing.Size(182, 106);
            // 
            // menuChonNhac
            // 
            this.menuChonNhac.Name = "menuChonNhac";
            this.menuChonNhac.Size = new System.Drawing.Size(181, 24);
            this.menuChonNhac.Text = "Chọn nhạc";
            this.menuChonNhac.Click += new System.EventHandler(this.menuChonNhac_Click);
            // 
            // menuPhatNhac
            // 
            this.menuPhatNhac.Name = "menuPhatNhac";
            this.menuPhatNhac.Size = new System.Drawing.Size(181, 24);
            this.menuPhatNhac.Text = "Phát nhạc";
            this.menuPhatNhac.Click += new System.EventHandler(this.menuPhatNhac_Click);
            // 
            // menuTamDung
            // 
            this.menuTamDung.Name = "menuTamDung";
            this.menuTamDung.Size = new System.Drawing.Size(181, 24);
            this.menuTamDung.Text = "Tạm dừng nhạc";
            this.menuTamDung.Click += new System.EventHandler(this.menuTamDung_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(178, 6);
            // 
            // menuDangXuat
            // 
            this.menuDangXuat.Name = "menuDangXuat";
            this.menuDangXuat.Size = new System.Drawing.Size(181, 24);
            this.menuDangXuat.Text = "Đăng xuất";
            this.menuDangXuat.Click += new System.EventHandler(this.menuDangXuat_Click);
            // 
            // frmMain
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1816, 913);
            this.ContextMenuStrip = this.ctxMenuChoiGame;
            this.Controls.Add(this.picHinhDaiDien);
            this.Controls.Add(this.picXoc);
            this.Controls.Add(this.lblDiem);
            this.Controls.Add(this.lblTenNguoiChoi);
            this.Controls.Add(this.groupBox1);
            this.Controls.Add(this.pictureBox1);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.FixedSingle;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "frmMain";
            this.Text = "Chơi game";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.FormClosing += new System.Windows.Forms.FormClosingEventHandler(this.frmMain_FormClosing);
            this.Load += new System.EventHandler(this.frmMain_Load);
            this.groupBox1.ResumeLayout(false);
            this.groupBox1.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox4)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox7)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox5)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox6)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKetQua3)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKetQua2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picKetQua1)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox2)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picHinhDaiDien)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.picXoc)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pictureBox1)).EndInit();
            this.ctxMenuChoiGame.ResumeLayout(false);
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.PictureBox pictureBox1;
        private System.Windows.Forms.GroupBox groupBox1;
        private System.Windows.Forms.Label label2;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.TextBox txtDatGa;
        private System.Windows.Forms.TextBox txtDatBau;
        private System.Windows.Forms.TextBox txtDatTom;
        private System.Windows.Forms.TextBox txtDatCua;
        private System.Windows.Forms.TextBox txtDatCa;
        private System.Windows.Forms.TextBox txtDatNai;
        private System.Windows.Forms.PictureBox pictureBox7;
        private System.Windows.Forms.PictureBox pictureBox6;
        private System.Windows.Forms.PictureBox pictureBox3;
        private System.Windows.Forms.PictureBox picKetQua3;
        private System.Windows.Forms.PictureBox picKetQua2;
        private System.Windows.Forms.PictureBox picKetQua1;
        private System.Windows.Forms.PictureBox pictureBox2;
        private System.Windows.Forms.PictureBox pictureBox4;
        private System.Windows.Forms.PictureBox pictureBox5;
        private System.Windows.Forms.Label lblTenNguoiChoi;
        private System.Windows.Forms.Label lblDiem;
        private System.Windows.Forms.PictureBox picXoc;
        private System.Windows.Forms.PictureBox picHinhDaiDien;
        private System.Windows.Forms.ToolTip ttipHinhDaiDien;
        private System.Windows.Forms.ContextMenuStrip ctxMenuChoiGame;
        private System.Windows.Forms.ToolStripMenuItem menuDangXuat;
        private System.Windows.Forms.ToolStripMenuItem menuChonNhac;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripMenuItem menuPhatNhac;
        private System.Windows.Forms.ToolStripMenuItem menuTamDung;
    }
}

